package com.example.aidangorospecs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBObject extends SQLiteOpenHelper
{

    public static final String EVENT_TABLE = "EVENT_TABLE";
    public static final String EVENT_NAME = "EVENT_NAME";
    public static final String EVENT_DESC = "EVENT_DESC";
    public static final String EVENT_ID = "ID";

    public DBObject(@Nullable Context context) {
        super(context, "event.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "Create Table " + EVENT_TABLE + " (" + EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + EVENT_NAME + " TEXT, " + EVENT_DESC + " TEXT)";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(EventModel eventModel)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(EVENT_NAME, eventModel.getDate());
        cv.put(EVENT_DESC, eventModel.getDesc());

        db.insert(EVENT_TABLE, null,cv);

        return true;
    }

    public boolean removeOne(EventModel eventModel)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + EVENT_TABLE + " WHERE " + EVENT_ID + " = " + eventModel.getId();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public ArrayList<EventModel> getAll()
    {
        ArrayList<EventModel> eventList = new ArrayList<>();

        String queryString = "Select * From " + EVENT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst())
        {
            do
            {
                int eventID = cursor.getInt(0);
                String eventName = cursor.getString(1);
                String eventDesc = cursor.getString(2);

                EventModel newEvent = new EventModel(eventID, eventName, eventDesc);
                eventList.add(newEvent);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return eventList;
    }
}
