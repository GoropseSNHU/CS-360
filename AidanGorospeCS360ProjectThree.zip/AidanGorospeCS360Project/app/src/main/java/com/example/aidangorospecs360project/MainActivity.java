package com.example.aidangorospecs360project;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    Button addEvent;
    EditText eventDate, eventDescription;
    Switch wifiSwitch;
    ListView eventList;
    private static final String channel_ID = "channel";

    private static final int notification_ID = 1;

    private NotificationManager notificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addEvent = findViewById(R.id.addEvent);
        eventDate = findViewById(R.id.eventDate);
        eventDescription = findViewById(R.id.eventDescription);
        wifiSwitch = findViewById(R.id.wifiSwitch);
        eventList = findViewById(R.id.eventList);
        DBObject dbObject = new DBObject(MainActivity.this);
        ArrayList<EventModel> events = dbObject.getAll();
        ArrayAdapter eventAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, events);
        eventList.setAdapter(eventAdapter);
        createNotificationChannel();
        eventList.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                EventModel event = (EventModel) parent.getItemAtPosition(position);
                dbObject.removeOne(event);
                ArrayAdapter eventAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, events);
                eventList.setAdapter(eventAdapter);
                if(wifiSwitch.isEnabled())
                {
                    showNotifEventRemove();
                }
            }
        });
    }

    public void createEvent(View view)
    {
        EventModel eventModel = new EventModel(-1, eventDate.getText().toString(), eventDescription.getText().toString());

        DBObject dbObject = new DBObject(MainActivity.this);
        dbObject.addOne(eventModel);
        ArrayList<EventModel> events = dbObject.getAll();
        ArrayAdapter eventAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, events);
        eventList.setAdapter(eventAdapter);
        if(wifiSwitch.isEnabled())
        {
            showNotifEventAdd();
        }
    }


    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is not in the Support Library.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "EventNotifs";
            String description = "Notifs for eventapp";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(channel_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this.
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void showNotifEventAdd()
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channel_ID)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle("Event Added")
                .setContentText("Event successfully added")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                // Set the intent that fires when the user taps the notification.
                .setContentIntent(pendingIntent);
                builder.setAutoCancel(true);
        Notification notification;
        notification = builder.build();
        notificationManager.notify(notification_ID, notification);
    }

    public void showNotifEventRemove()
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channel_ID)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle("Event Removed")
                .setContentText("Event successfully removed")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                // Set the intent that fires when the user taps the notification.
                .setContentIntent(pendingIntent);
        builder.setAutoCancel(true);
        Notification notification;
        notification = builder.build();
        notificationManager.notify(notification_ID, notification);
    }

}