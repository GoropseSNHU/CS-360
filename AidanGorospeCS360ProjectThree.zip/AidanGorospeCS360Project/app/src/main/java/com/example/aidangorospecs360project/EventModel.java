package com.example.aidangorospecs360project;

import java.util.ArrayList;

public class EventModel {
    private int id;
    private String date;
    private String desc;

    public EventModel(int id, String date, String desc) {
        this.id = id;
        this.date = date;
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "EventModel{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getDesc() {
        return desc;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setId(int id) {
        this.id = id;
    }
}
